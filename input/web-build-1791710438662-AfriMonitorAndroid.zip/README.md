# Afri Monitor — Android starter

This Android Studio project opens `https://office.afrigames.bet`, lets you log in normally, then attempts to click the dashboard's `REFRESH DATA` control every second and notify you about newly detected visible rows containing `PENDING` but not `COMPLETED`.

## Build
1. Install Android Studio on a computer.
2. Open this project folder and allow Gradle to sync.
3. Connect your Android phone with USB debugging enabled.
4. Press Run, or use Build > Build APK(s).

## Important limitations
- This is source code, not a compiled APK, and has not been tested against the live dashboard's page structure.
- The dashboard's HTML may require tuning the refresh-button and row-detection logic.
- The first scan records existing pending rows and does not alert for them; it alerts only for newly appearing rows.
- Keep the app open for reliable one-second checking. Android may pause WebView timers in the background or when the device sleeps; this prototype does not guarantee alerts when closed or locked.
- Allow notifications when prompted. Do not share your password; log in only on the official HTTPS dashboard.
- Test carefully before relying on it for withdrawal operations.
