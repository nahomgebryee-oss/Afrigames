plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.afrigames.monitor"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.afrigames.monitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
