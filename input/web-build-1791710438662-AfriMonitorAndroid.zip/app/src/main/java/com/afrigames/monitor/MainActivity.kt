package com.afrigames.monitor

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private var monitoring = false
    private var firstScan = true
    private val seen = mutableSetOf<String>()
    private val channelId = "pending_withdrawals"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 16, 6))
        }
        root.addView(TextView(this).apply {
            text = "AFRI MONITOR  •  Withdrawal alerts"
            textSize = 19f
            setTextColor(Color.rgb(195, 235, 55))
            setPadding(16, 18, 16, 12)
        })
        status = TextView(this).apply {
            text = "Log in to the dashboard, then start monitoring."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(16, 8, 16, 8)
        }
        root.addView(status)
        val start = Button(this).apply {
            text = "START MONITORING"
            setOnClickListener {
                monitoring = !monitoring
                text = if (monitoring) "STOP MONITORING" else "START MONITORING"
                if (monitoring) {
                    firstScan = true
                    status.text = "Monitoring active. Keep this app open."
                    web.evaluateJavascript(pollScript(), null)
                } else {
                    web.evaluateJavascript("window.__afriStop && window.__afriStop();", null)
                    status.text = "Monitoring stopped."
                }
            }
        }
        root.addView(start)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            CookieManager.getInstance().setAcceptCookie(true)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    status.text = "Dashboard loaded. Log in if needed, then start monitoring."
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(Bridge(), "AfriNative")
            loadUrl("https://office.afrigames.bet")
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun pollScript() = """
      (function(){
        if(window.__afriTimer) clearInterval(window.__afriTimer);
        function scan(){
          try {
            const els = Array.from(document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"]'));
            const refresh = els.find(e => ((e.innerText || e.value || '').trim()).toUpperCase().includes('REFRESH DATA'));
            if(refresh && !refresh.disabled) refresh.click();
            const nodes = Array.from(document.querySelectorAll('tr,[role="row"],li,article,section,div'));
            const found = [];
            for(const e of nodes){
              const txt=(e.innerText||'').replace(/\s+/g,' ').trim();
              if(!txt || txt.length>900 || !/\bPENDING\b/i.test(txt) || /\bCOMPLETED\b/i.test(txt)) continue;
              if(e.querySelectorAll('*').length>35) continue;
              if(Array.from(e.children).some(c=>/\bPENDING\b/i.test(c.innerText||'') && !/\bCOMPLETED\b/i.test(c.innerText||''))) continue;
              const key=txt.slice(0,450);
              if(!found.includes(key)) found.push(key);
            }
            AfriNative.onScan(JSON.stringify(found));
          } catch(err) { AfriNative.onError(String(err)); }
        }
        scan();
        window.__afriTimer=setInterval(scan,1000);
        window.__afriStop=function(){clearInterval(window.__afriTimer);};
      })();
    """.trimIndent()

    inner class Bridge {
        @JavascriptInterface fun onScan(json: String) {
            runOnUiThread {
                try {
                    val arr = JSONArray(json)
                    val current = mutableSetOf<String>()
                    for (i in 0 until arr.length()) current.add(arr.getString(i))
                    if (firstScan) {
                        seen.addAll(current)
                        firstScan = false
                        status.text = "Monitoring active — existing pending rows ignored."
                    } else {
                        val fresh = current.filter { !seen.contains(it) }
                        seen.addAll(current)
                        fresh.forEach { notifyPending(it) }
                        status.text = if (fresh.isNotEmpty())
                            "New pending request detected (${fresh.size})."
                        else "Monitoring active — checking every second."
                        if (seen.size > 500) seen.retainAll(current)
                    }
                } catch (_: Exception) {}
            }
        }
        @JavascriptInterface fun onError(message: String) {
            runOnUiThread { status.text = "Monitor issue: $message" }
        }
    }

    private fun notifyPending(details: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("New pending withdrawal")
            .setContentText(details.take(160))
            .setStyle(NotificationCompat.BigTextStyle().bigText(details.take(450)))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val c = NotificationChannel(channelId, "Pending withdrawal alerts", NotificationManager.IMPORTANCE_HIGH)
            c.description = "Alerts for newly detected pending withdrawal requests"
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
